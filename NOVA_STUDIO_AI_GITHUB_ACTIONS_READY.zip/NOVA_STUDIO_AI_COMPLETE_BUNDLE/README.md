# NOVA STUDIO AI — GitHub Actions Ready Android Project

বাংলা Cyberpunk Android starter project built with Kotlin + Jetpack Compose.

## Build APK with GitHub Actions
Read **GITHUB_ACTIONS_BUILD_BN.md**. The included workflow is:
`.github/workflows/android-apk.yml`

It builds `:app:assembleDebug` using JDK 17, Android SDK 35, and Gradle 8.11.1, then uploads the APK as a GitHub Actions artifact.

## Project details
- Application ID: `com.nova.studio.ai`
- Minimum Android: API 26
- Compile SDK: 35
- Android Gradle Plugin: 8.9.2
- Kotlin: 2.0.21
- Gradle: 8.11.1

## Notes
This is a feature-rich starter bundle, not yet a production-complete mobile IDE. See `FEATURES_AND_LIMITATIONS_BN.md` for implemented modules and remaining limitations. Never commit API keys, GitHub tokens, keystores, or passwords.
