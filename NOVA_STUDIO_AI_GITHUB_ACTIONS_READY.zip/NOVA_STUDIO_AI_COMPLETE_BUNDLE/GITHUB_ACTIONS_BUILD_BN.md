# GitHub দিয়ে NOVA STUDIO AI APK Build — বাংলা নির্দেশনা

এই প্রজেক্টে `.github/workflows/android-apk.yml` আগে থেকেই যোগ করা আছে। GitHub Actions cloud runner-এ JDK 17, Android SDK 35 এবং Gradle 8.11.1 ব্যবহার করে Debug APK তৈরি করবে। এই workflow-এর জন্য Gradle Wrapper JAR প্রয়োজন নেই।

## ১) ZIP Extract করো
- `NOVA_STUDIO_AI_GITHUB_ACTIONS_READY.zip` Extract করো।
- Extract করা `NOVA_STUDIO_AI_COMPLETE_BUNDLE` ফোল্ডারটি খোলো।
- ওই ফোল্ডারের ভেতরের সব ফাইল ও ফোল্ডার (বিশেষ করে `.github`) GitHub repository-র root-এ upload করতে হবে।
- ZIP ফাইলটিকে শুধু repository-তে রেখে দিলে হবে না; ভেতরের project files repository-র root-এ থাকতে হবে।

## ২) GitHub Repository তৈরি করো
- GitHub-এ sign in করে নতুন repository তৈরি করো।
- Repository-টি Public বা Private যেটি চাও রাখতে পারো।
- Repository-র `Add file` → `Upload files` ব্যবহার করে Extract করা project-এর contents upload করো।
- `.github/workflows/android-apk.yml`-ও upload হয়েছে কি না নিশ্চিত করো।
- Commit changes করো।

## ৩) APK Build চালাও
- Repository-র `Actions` tab খোলো।
- `Build NOVA STUDIO AI APK` workflow নির্বাচন করো।
- প্রথম commit-এ workflow নিজে থেকেই শুরু হওয়ার কথা। না হলে `Run workflow` চাপো।
- Build শেষ না হওয়া পর্যন্ত অপেক্ষা করো। প্রথম build-এ dependencies download হওয়ায় কিছুটা সময় লাগতে পারে।

## ৪) APK Download করো
- Workflow run-এ সবুজ checkmark এলে সেটি খোলো।
- নিচের `Artifacts` অংশে `NOVA-STUDIO-AI-debug-apk` চাপো।
- Artifact ZIP download হবে। সেটি Extract করলে `app-debug.apk` পাবে।

## Build ব্যর্থ হলে
- Actions run খুলে লাল failed job নির্বাচন করো।
- `Build Debug APK` step-এর প্রথম `e:` বা `FAILURE:` error সহ শেষের 30–50 লাইন কপি করে সাহায্য চাও, অথবা screenshot দাও।
- API key, GitHub token, password বা signing key কখনো log/screenshot-এ দেবে না।

## গুরুত্বপূর্ণ
- এটি Debug APK; Play Store/Release-এর জন্য আলাদা release signing configuration প্রয়োজন।
- GitHub Actions build চালাতে GitHub account ও repository দরকার। Public repository-তে code সবাই দেখতে পারে; API key বা ব্যক্তিগত token কখনো source code-এ লিখবে না।
- এই workflow build চালায়; build সফল হবে কি না তা GitHub Actions-এর result-ই নিশ্চিত করবে। এখানে আগে থেকে APK build সফল হয়েছে বলে দাবি করা হচ্ছে না।
