package com.nova.studio.ai.modules

object UiTemplates {
    val templates = listOf(
        "Neon Dashboard" to "Dark dashboard with statistic cards, navigation and glowing accent buttons.",
        "AI Chat" to "Chat bubbles, prompt composer, model selector and streaming response area.",
        "Login Screen" to "Email/password fields, validation messages and privacy link.",
        "Profile Screen" to "Avatar placeholder, user details, settings and sign-out action.",
        "Product Catalog" to "Search bar, category chips, product cards and detail page."
    )
}
