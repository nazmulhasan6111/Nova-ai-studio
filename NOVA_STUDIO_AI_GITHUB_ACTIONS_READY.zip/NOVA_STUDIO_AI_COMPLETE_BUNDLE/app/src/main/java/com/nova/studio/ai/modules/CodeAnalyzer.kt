package com.nova.studio.ai.modules

/**
 * Offline, heuristic source checker. This is not a replacement for compiler/lint.
 */
object CodeAnalyzer {
    data class Finding(val severity: String, val line: Int, val message: String)

    fun analyze(source: String): List<Finding> {
        val findings = mutableListOf<Finding>()
        val lines = source.lines()
        lines.forEachIndexed { index, line ->
            val n = index + 1
            if ("TODO()" in line) findings += Finding("ERROR", n, "TODO() throws at runtime; implement this function.")
            if ("GlobalScope.launch" in line) findings += Finding("WARNING", n, "Prefer lifecycle-aware coroutine scopes.")
            if ("http://" in line && "localhost" !in line) findings += Finding("WARNING", n, "Unencrypted HTTP URL found.")
            if (Regex("""api[_-]?key\s*=\s*["'][^"']+["']""", RegexOption.IGNORE_CASE).containsMatchIn(line))
                findings += Finding("SECURITY", n, "Possible hard-coded API key. Move secrets out of source code.")
            if ("!!" in line) findings += Finding("INFO", n, "Non-null assertion may cause a crash.")
        }
        val opens = source.count { it == '{' }
        val closes = source.count { it == '}' }
        if (opens != closes) findings += Finding("ERROR", 1, "Brace count mismatch: $opens opening vs $closes closing.")
        return findings
    }
}
