package com.nova.studio.ai

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF080B14)
private val Panel = Color(0xFF111827)
private val Panel2 = Color(0xFF172238)
private val Neon = Color(0xFF00E5FF)
private val Purple = Color(0xFF9B5CFF)
private val TextMain = Color(0xFFEAF2FF)
private val TextMuted = Color(0xFF9AAAC4)
private val Green = Color(0xFF4DE3A2)
private val Red = Color(0xFFFF718B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}

data class ChatLine(val role: String, val text: String)

@Composable
fun NovaApp() {
    var page by remember { mutableStateOf("হোম") }
    var apiBase by remember { mutableStateOf("https://api.openai.com/v1") }
    var apiKey by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("gpt-4o-mini") }
    var githubToken by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Ready") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val projectRoot = remember {
        File(context.filesDir, "projects").apply { mkdirs() }
    }
    var projectNames by remember { mutableStateOf(projectRoot.listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList()) }
    var selectedProject by remember { mutableStateOf("") }
    var chat by remember { mutableStateOf(listOf(ChatLine("assistant", "স্বাগতম! আমি NOVA AI। কী তৈরি করতে চাও?"))) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon,
            secondary = Purple,
            background = Bg,
            surface = Panel,
            onPrimary = Bg,
            onBackground = TextMain,
            onSurface = TextMain
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val nav = listOf("হোম", "AI", "Projects", "Tools", "Settings")
                    val icons = listOf(Icons.Default.Home, Icons.Default.SmartToy, Icons.Default.Folder, Icons.Default.Terminal, Icons.Default.Settings)
                    nav.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = page == label,
                            onClick = { page = label },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Neon,
                                selectedTextColor = Neon,
                                indicatorColor = Panel2,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).background(Bg)
            ) {
                TopHeader(status)
                when (page) {
                    "হোম" -> HomeScreen(
                        onOpen = { page = it },
                        projectCount = projectNames.size
                    )
                    "AI" -> AssistantScreen(
                        chat = chat,
                        onSend = { prompt ->
                            val history = chat + ChatLine("user", prompt)
                            chat = history
                            if (apiKey.isBlank()) {
                                chat = history + ChatLine("assistant", "প্রথমে Settings থেকে API Base URL, API Key এবং Model সেট করো।")
                            } else {
                                scope.launch {
                                    status = "AI কাজ করছে..."
                                    val answer = AiClient.chat(apiBase, apiKey, model, history)
                                    chat = history + ChatLine("assistant", answer)
                                    status = "Ready"
                                }
                            }
                        }
                    )
                    "Projects" -> ProjectsScreen(
                        names = projectNames,
                        selected = selectedProject,
                        onSelect = { selectedProject = it },
                        onCreate = { name ->
                            val safe = name.trim().replace(Regex("[^A-Za-z0-9_-]"), "_")
                            if (safe.isNotBlank()) {
                                File(projectRoot, safe).mkdirs()
                                projectNames = projectRoot.listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList()
                                selectedProject = safe
                            }
                        },
                        onRefresh = {
                            projectNames = projectRoot.listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList()
                        },
                        root = projectRoot
                    )
                    "Tools" -> ToolsScreen(
                        onTerminal = {
                            try {
                                val intent = Intent("com.termux.RUN_COMMAND").apply {
                                    setClassName("com.termux", "com.termux.app.RunCommandService")
                                    putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
                                    putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", "echo NOVA_STUDIO_AI_READY; pwd"))
                                    putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
                                    putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
                                }
                                context.startService(intent)
                                status = "Termux command sent"
                            } catch (_: Exception) {
                                status = "Termux পাওয়া যায়নি / Permission configure করো"
                            }
                        },
                        onGithub = {
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com")))
                            } catch (_: ActivityNotFoundException) { status = "Browser পাওয়া যায়নি" }
                        },
                        onBuildInfo = { status = "Build: Code on the Go / compatible local Gradle toolchain প্রয়োজন" }
                    )
                    "Settings" -> SettingsScreen(
                        apiBase = apiBase,
                        onBase = { apiBase = it },
                        apiKey = apiKey,
                        onKey = { apiKey = it },
                        model = model,
                        onModel = { model = it },
                        githubToken = githubToken,
                        onGithubToken = { githubToken = it },
                        onTest = {
                            scope.launch {
                                status = "API পরীক্ষা হচ্ছে..."
                                status = AiClient.test(apiBase, apiKey)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun TopHeader(status: String) {
    Row(
        Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).background(Neon.copy(alpha = .13f), RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center
        ) { Text("N", color = Neon, fontWeight = FontWeight.Black, fontSize = 25.sp) }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("NOVA STUDIO", color = TextMain, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            Text("AI DEVELOPMENT SYSTEM", color = Neon, fontSize = 9.sp, letterSpacing = 1.5.sp)
        }
        Text(status, color = if (status == "Ready") Green else Neon, fontSize = 10.sp)
    }
}

@Composable
private fun HomeScreen(onOpen: (String) -> Unit, projectCount: Int) {
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item {
            Text("স্বাগতম, Developer 👋", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("তোমার AI-powered development workspace", color = TextMuted, fontSize = 13.sp)
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Panel2),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("BUILD SOMETHING AMAZING", color = Neon, fontSize = 10.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("আইডিয়া থেকে অ্যাপ — AI-এর সাহায্যে", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("কোড তৈরি করো, Error বুঝো এবং Project পরিচালনা করো।", color = TextMuted, fontSize = 12.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = { onOpen("AI") }, colors = ButtonDefaults.buttonColors(containerColor = Neon)) {
                        Text("AI দিয়ে শুরু করো", color = Bg, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Default.ArrowForward, null, tint = Bg)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("PROJECTS", projectCount.toString(), Modifier.weight(1f))
                StatCard("AI MODE", "API", Modifier.weight(1f))
                StatCard("PLATFORM", "ANDROID", Modifier.weight(1f))
            }
        }
        item { Text("QUICK ACCESS", color = Neon, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp) }
        val tools = listOf(
            Triple("AI Assistant", "কোড লিখতে ও প্রশ্ন করতে", "AI"),
            Triple("Project Manager", "Project ও File তৈরি করতে", "Projects"),
            Triple("Developer Tools", "Termux, GitHub, Build", "Tools"),
            Triple("API Settings", "নিজের AI API যুক্ত করতে", "Settings")
        )
        items(tools) { item ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onOpen(item.third) },
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(15.dp)
            ) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).background(Purple.copy(alpha = .16f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Bolt, null, tint = Neon)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.first, color = TextMain, fontWeight = FontWeight.SemiBold)
                        Text(item.second, color = TextMuted, fontSize = 11.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Neon)
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(13.dp)) {
        Column(Modifier.padding(11.dp)) {
            Text(label, color = TextMuted, fontSize = 8.sp)
            Text(value, color = Neon, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun AssistantScreen(chat: List<ChatLine>, onSend: (String) -> Unit) {
    var prompt by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("NOVA AI ASSISTANT", color = Neon, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text("API সেটিংস থেকে Provider configure করো।", color = TextMuted, fontSize = 11.sp)
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(chat) { line ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.role == "user") Arrangement.End else Arrangement.Start) {
                    Surface(
                        color = if (line.role == "user") Color(0xFF18364A) else Panel,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.widthIn(max = 310.dp)
                    ) {
                        Text(line.text, color = TextMain, modifier = Modifier.padding(12.dp), fontSize = 13.sp)
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("কী তৈরি করতে চাও?", color = TextMuted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Neon,
                    unfocusedBorderColor = Panel2,
                    focusedTextColor = TextMain,
                    unfocusedTextColor = TextMain
                ),
                maxLines = 4
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = {
                val p = prompt.trim()
                if (p.isNotEmpty()) { onSend(p); prompt = "" }
            }) {
                Icon(Icons.Default.Send, "Send", tint = Neon)
            }
        }
    }
}

@Composable
private fun ProjectsScreen(
    names: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    onCreate: (String) -> Unit,
    onRefresh: () -> Unit,
    root: File
) {
    var newName by remember { mutableStateOf("") }
    var fileName by remember { mutableStateOf("Main.kt") }
    var code by remember { mutableStateOf("// NOVA STUDIO AI\n// এখানে তোমার কোড লিখো\n") }
    var message by remember { mutableStateOf("Project ফোনের App Storage-এ রাখা হয়।") }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("PROJECT WORKSPACE", color = Neon, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text(message, color = TextMuted, fontSize = 11.sp)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = newName, onValueChange = { newName = it },
                modifier = Modifier.weight(1f), label = { Text("নতুন Project নাম") },
                singleLine = true
            )
            Spacer(Modifier.width(7.dp))
            Button(onClick = { onCreate(newName); newName = ""; message = "Project তৈরি হয়েছে" }) {
                Icon(Icons.Default.Add, null)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("তোমার Projects", color = TextMain, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onRefresh) { Text("Refresh") }
        }
        LazyColumn(Modifier.heightIn(max = 150.dp)) {
            items(names) { name ->
                Row(
                    Modifier.fillMaxWidth().clickable { onSelect(name) }.background(if (selected == name) Panel2 else Bg, RoundedCornerShape(9.dp)).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Folder, null, tint = Neon)
                    Spacer(Modifier.width(8.dp))
                    Text(name, color = TextMain)
                }
            }
        }
        if (selected.isNotBlank()) {
            Text("Selected: $selected", color = Neon, fontSize = 12.sp)
            OutlinedTextField(fileName, { fileName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("File name") }, singleLine = true)
            OutlinedTextField(
                code, { code = it }, modifier = Modifier.weight(1f).fillMaxWidth(),
                label = { Text("Code Editor") }, minLines = 8,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Neon, unfocusedBorderColor = Panel2,
                    focusedTextColor = TextMain, unfocusedTextColor = TextMain
                )
            )
            Button(
                onClick = {
                    val safeFile = fileName.trim().replace(Regex("[^A-Za-z0-9._-]"), "_")
                    if (safeFile.isNotBlank()) {
                        File(File(root, selected), safeFile).writeText(code)
                        message = "ফাইল Save হয়েছে: $safeFile"
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(7.dp)); Text("ফাইল Save করো") }
        } else {
            Text("একটি Project নির্বাচন করো অথবা নতুন Project তৈরি করো।", color = TextMuted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ToolsScreen(onTerminal: () -> Unit, onGithub: () -> Unit, onBuildInfo: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("DEVELOPER TOOLS", color = Neon, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text("কিছু Tool চালাতে আলাদা অ্যাপ বা SDK প্রয়োজন।", color = TextMuted, fontSize = 12.sp)
        ToolButton("Termux Terminal", "Termux-এর অনুমোদিত command integration", Icons.Default.Terminal, onTerminal)
        ToolButton("GitHub", "Repository ও source code browser খুলুন", Icons.Default.Code, onGithub)
        ToolButton("APK Build Setup", "Local Gradle Build Environment-এর নির্দেশনা", Icons.Default.Build, onBuildInfo)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(14.dp)) {
                Text("Build Status", color = Neon, fontWeight = FontWeight.Bold)
                Text("এই Starter সংস্করণ নিজে থেকে অন্য Android Project compile করে না। Build করতে compatible local Gradle + Android SDK toolchain দরকার।", color = TextMuted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ToolButton(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Neon, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = TextMain, fontWeight = FontWeight.Bold)
                Text(subtitle, color = TextMuted, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Purple)
        }
    }
}

@Composable
private fun SettingsScreen(
    apiBase: String, onBase: (String) -> Unit,
    apiKey: String, onKey: (String) -> Unit,
    model: String, onModel: (String) -> Unit,
    githubToken: String, onGithubToken: (String) -> Unit,
    onTest: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("API & SECURITY SETTINGS", color = Neon, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Text("OpenAI-compatible API configuration", color = TextMuted, fontSize = 12.sp)
        OutlinedTextField(apiBase, onBase, modifier = Modifier.fillMaxWidth(), label = { Text("API Base URL") }, singleLine = true)
        OutlinedTextField(apiKey, onKey, modifier = Modifier.fillMaxWidth(), label = { Text("API Key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
        OutlinedTextField(model, onModel, modifier = Modifier.fillMaxWidth(), label = { Text("Model ID") }, singleLine = true)
        Button(onClick = onTest, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.NetworkCheck, null); Spacer(Modifier.width(8.dp)); Text("API Connection Test")
        }
        Divider(color = Panel2)
        Text("GitHub (পরবর্তী Integration-এর জন্য)", color = TextMain, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            githubToken, onGithubToken, modifier = Modifier.fillMaxWidth(),
            label = { Text("GitHub Token (এই session-এ)") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true
        )
        Text(
            "গুরুত্বপূর্ণ: এই Starter-এ API Key ও Token শুধু অ্যাপের চলতি session-এ memory-তে থাকে; অ্যাপ বন্ধ হলে আবার দিতে হবে। Production ব্যবহারের আগে Android Keystore encryption যোগ করো। কোনো Key Source Code বা GitHub-এ রেখো না।",
            color = TextMuted, fontSize = 11.sp
        )
    }
}

private object AiClient {
    private val client = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun test(base: String, key: String): String = withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext "API Key দাও"
        try {
            val url = base.trimEnd('/') + "/models"
            val request = Request.Builder().url(url).header("Authorization", "Bearer $key").get().build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) "API Connected ✓ (${response.code})"
                else "API Error: HTTP ${response.code}"
            }
        } catch (e: Exception) {
            "Connection Error: ${e.message ?: "Unknown error"}"
        }
    }

    suspend fun chat(base: String, key: String, model: String, history: List<ChatLine>): String =
        withContext(Dispatchers.IO) {
            try {
                val messages = JSONArray()
                history.forEach { line ->
                    messages.put(JSONObject().put("role", line.role).put("content", line.text))
                }
                val payload = JSONObject()
                    .put("model", model)
                    .put("messages", messages)
                    .put("temperature", 0.4)
                val body = payload.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url(base.trimEnd('/') + "/chat/completions")
                    .header("Authorization", "Bearer $key")
                    .post(body)
                    .build()
                client.newCall(request).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) return@withContext "AI API Error (${response.code}): ${raw.take(500)}"
                    val json = JSONObject(raw)
                    json.getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .optString("content", "খালি উত্তর পাওয়া গেছে।")
                }
            } catch (e: Exception) {
                "দুঃখিত, AI Request ব্যর্থ হয়েছে: ${e.message ?: "Unknown error"}"
            }
        }
}
