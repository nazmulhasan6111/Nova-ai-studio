package com.nova.studio.ai.modules

object SecurityScanner {
    data class Issue(val level: String, val detail: String)

    fun scan(text: String): List<Issue> = buildList {
        if (Regex("""-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----""").containsMatchIn(text))
            add(Issue("CRITICAL", "Private key material appears in this file. Remove it and rotate the key."))
        if (Regex("""(sk-[A-Za-z0-9_-]{16,}|ghp_[A-Za-z0-9]{20,})""").containsMatchIn(text))
            add(Issue("HIGH", "Possible API/GitHub token detected. Revoke and replace exposed credentials."))
        if (Regex("""http://(?!localhost|127\.0\.0\.1)""").containsMatchIn(text))
            add(Issue("MEDIUM", "Plain HTTP endpoint found. Prefer HTTPS."))
        if (text.contains("android:allowBackup=\"true\""))
            add(Issue("MEDIUM", "Android backup is enabled; review whether sensitive app data can be exported."))
        if (isEmpty()) add(Issue("INFO", "No matching basic security patterns found. This is not a full security audit."))
    }
}
