package com.nova.studio.ai.modules

object BackendGenerator {
    fun kotlinDataClass(name: String, fields: List<Pair<String, String>>): String {
        val safeName = name.filter { it.isLetterOrDigit() || it == '_' }.ifBlank { "GeneratedModel" }
        val body = fields.joinToString("\n") { (field, type) ->
            val safeField = field.filter { it.isLetterOrDigit() || it == '_' }.ifBlank { "field" }
            "    val $safeField: ${allowedType(type)}"
        }
        return "data class $safeName(\n$body\n)"
    }

    private fun allowedType(type: String): String = when (type.lowercase()) {
        "string" -> "String"
        "int", "integer" -> "Int"
        "long" -> "Long"
        "boolean", "bool" -> "Boolean"
        "double" -> "Double"
        "float" -> "Float"
        "list<string>" -> "List<String>"
        else -> "String"
    }
}
