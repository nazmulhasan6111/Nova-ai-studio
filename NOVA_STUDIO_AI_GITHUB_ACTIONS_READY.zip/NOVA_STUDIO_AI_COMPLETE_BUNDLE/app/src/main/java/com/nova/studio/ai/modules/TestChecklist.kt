package com.nova.studio.ai.modules

object TestChecklist {
    val checks = listOf(
        "App launches without crashing",
        "Navigation works on small screens",
        "Empty and invalid API settings show helpful errors",
        "Network failure is handled without app crash",
        "API keys are not written into source files or logs",
        "Project/file operations stay inside the app project directory",
        "Termux action is optional and handles Termux-not-installed",
        "APK installs on the target Android version",
        "Release build is signed with a user-controlled keystore"
    )
}
