package com.nova.studio.ai.modules

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * GitHub REST API helper. User must supply their own token and approve scopes.
 * Never commit tokens into a project or share them in screenshots.
 */
class GitHubApi {
    private val client = OkHttpClient.Builder()
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    fun listRepositories(token: String): Result<List<String>> = runCatching {
        require(token.isNotBlank()) { "GitHub token is missing." }
        val request = Request.Builder()
            .url("https://api.github.com/user/repos?per_page=50&sort=updated")
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            check(response.isSuccessful) { "GitHub API ${response.code}: $body" }
            val arr = JSONArray(body)
            (0 until arr.length()).map { i ->
                val item = arr.getJSONObject(i)
                item.optString("full_name") + " — " + item.optString("html_url")
            }
        }
    }

    fun createRepository(token: String, name: String, isPrivate: Boolean): Result<String> = runCatching {
        require(token.isNotBlank()) { "GitHub token is missing." }
        require(name.matches(Regex("[A-Za-z0-9_.-]{1,100}"))) { "Invalid repository name." }
        val json = JSONObject().put("name", name).put("private", isPrivate)
            .put("auto_init", true)
        val request = Request.Builder()
            .url("https://api.github.com/user/repos")
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            check(response.isSuccessful) { "GitHub API ${response.code}: $body" }
            JSONObject(body).optString("html_url")
        }
    }
}
