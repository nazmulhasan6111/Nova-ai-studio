package com.nova.studio.ai.modules

/**
 * Local build orchestration guide. The IDE/Gradle installation performs the actual build.
 * This app cannot silently install or execute an arbitrary Android SDK toolchain itself.
 */
object BuildGuide {
    val steps = listOf(
        "Open the generated project folder in Code on the Go.",
        "Wait for Gradle Sync and dependency downloads to finish.",
        "Run Gradle task :app:assembleDebug.",
        "Use Code on the Go's Export action to copy the generated APK to Downloads."
    )
    const val DEBUG_APK_PATH = "app/build/outputs/apk/debug/app-debug.apk"
    const val RELEASE_NOTE = "Release APK needs a signing key. Keep the keystore and passwords private."
}
