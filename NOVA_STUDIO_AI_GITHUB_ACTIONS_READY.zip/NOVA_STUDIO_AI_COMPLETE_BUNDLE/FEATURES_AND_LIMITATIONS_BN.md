# NOVA STUDIO AI — Feature Bundle (বাংলা)

## এই ZIP-এ যা আছে
- Cyber dark Jetpack Compose Android app shell এবং NOVA launcher icon
- OpenAI-compatible Chat Completions API integration (API key session-only)
- API connectivity test
- Local private project folders and basic text editor (existing starter screens)
- Android Compose starter-project generator module
- Offline heuristic code analyzer
- Basic security pattern scanner
- Kotlin data-class/backend model generator
- GitHub REST API helper: list repositories and create repository
- UI screen template catalogue
- Local APK build instructions for Code on the Go
- QA/testing checklist

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি একটি বিস্তৃত starter bundle, production-grade all-in-one IDE নয়।
- AI provider-এ OpenAI-compatible API endpoint/key/model দিতে হবে; provider-এর নীতি/খরচ আলাদা।
- GitHub API helper source-এ আছে; OAuth login, token vault এবং full Git clone/commit/push UI এখনো নেই।
- Code analyzer/security scanner heuristic; Android Lint, compiler বা professional security audit-এর বিকল্প নয়।
- BuildGuide Code on the Go-কে Gradle build চালাতে নির্দেশ করে; NOVA নিজে Android SDK/Gradle compiler bundle করে না।
- UI templates catalogue; drag-and-drop visual designer নয়।
- Backend helper Kotlin model তৈরি করে; server deploy, cloud database provisioning বা hosting করে না।
- App testing checklist দেয়; automated device farm বা full test runner নয়।
- Termux command support device/Termux settings/permission-এর উপর নির্ভরশীল।
- Wrapper JAR ইচ্ছাকৃতভাবে নেই; Code on the Go-এর Gradle task runner ব্যবহার করো।

## Build
1. ZIP extract করে `NOVA_STUDIO_AI_COMPLETE_BUNDLE` folder Code on the Go-তে open/import করো।
2. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করো।
3. Gradle task `:app:assembleDebug` চালাও।
4. Code on the Go-এর Export action দিয়ে APK বের করো।
5. Debug APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ পাওয়া যায়।

## নিরাপত্তা
- API key বা GitHub token কাউকে পাঠাবে না; source code-এ hardcode করবে না।
- GitHub token বানালে প্রয়োজনের চেয়ে বেশি permission দেবে না।
- Release keystore/password আলাদা নিরাপদ জায়গায় রাখবে।
